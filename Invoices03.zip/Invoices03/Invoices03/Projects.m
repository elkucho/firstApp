//
//  Projects.m
//  Invoices03
//
//  Created by Marco Lima on 2012-11-03.
//  Copyright (c) 2012 LIM4 Consulting Inc. All rights reserved.
//

#import "Projects.h"


@implementation Projects

@dynamic projDescription;
@dynamic projStatus;

@end
